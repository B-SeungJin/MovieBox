import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class JFrameDemo {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	private static void createAndShowGUI() {
		JFrame f = new JFrame("Button Demo");
		ButtonPanel bp = new ButtonPanel();
		
		f.add(bp);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(550, 550);
		f.setVisible(true);
	}

	
}

class ButtonPanel extends JPanel implements ActionListener{
	
	Color colors = Color.black;
	
	public ButtonPanel() {
		add(createButton("red", Color.red));
		add(createButton("blue", Color.blue));
		add(createButton("green", Color.green));
		
	}

	
	private JButton createButton(String text, Color background) {
		JButton button = new JButton(text);
		button.setBackground(background);
		button.addActionListener(this);
		
		return button;
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		JButton button = (JButton)e.getSource();
		this.colors = button.getBackground(); 
		repaint();
				
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(colors);
		g.drawLine(100, 200, 200, 200);

	}
}