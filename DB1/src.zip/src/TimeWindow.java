import javax.swing.*;

class TimeWindow extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TimeWindow() {
        setTitle("Time Selection");
        setSize(750, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

}
